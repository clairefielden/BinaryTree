import java.io.BufferedWriter;
import java.util.Scanner;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class AccessBSTApp
{       

static BinarySearchTree<Student> b = new BinarySearchTree<Student>();

    public static void printAllStudents() 
    {
        b.inOrder();
    }
 
    
    public static String printStudent(String stID)
    {
        Student f1 = new Student(stID, "", "");
        
        	
        if(b.find(f1)!= null)
        {
        	f1 = b.find(f1).getStudent();
        	return f1.getName()+" "+f1.getSurname();
        }
        else
        {
        	return "Access denied!";
        }
    }


public static void readInFile(String filename) throws FileNotFoundException 
{
	
    File f = new File("/home/fieldy/Assignment1/data/"+filename);
    Scanner scnr = new Scanner(f);

               
                while(scnr.hasNextLine())
                {
                    String sn = "";
                    String fn = "";
                    String ln = "";
                    
                    String line2 = scnr.nextLine();

                        for(int j = 0; j<9;j++)
                        {
                            sn = sn+line2.charAt(j);
                        }
                        int count = 10;
                        
                            while(line2.charAt(count)!=' ')
                            {
                                fn = fn+line2.charAt(count);
                                count++;
                            }
                        
                        
                        for (int l = count+1; l<line2.length(); l++)
                        {
                                ln = ln+line2.charAt(l);
                        }

                        Student element = new Student(sn, fn, ln);
                        	b.insert(element);
                }

                scnr.close();
}

public static void readInExperimentFile(String filename, int num) throws FileNotFoundException 
{
	
	
	
    File f = new File("/home/fieldy/Assignment1/data/"+filename);
    Scanner scnr = new Scanner(f);

                
		
                while(scnr.hasNextLine())
                {
                    String sn = "";
                    String fn = "";
                    String ln = "";
                    
                    String line2 = scnr.nextLine();

                        for(int j = 0; j<9;j++)
                        {
                            sn = sn+line2.charAt(j);
                        }
                        int count = 10;
                        
                            while(line2.charAt(count)!=' ')
                            {
                                fn = fn+line2.charAt(count);
                                count++;
                            }
                        
                        
                        for (int l = count+1; l<line2.length(); l++)
                        {
                                ln = ln+line2.charAt(l);
                        }

                         Student element = new Student(sn, fn, ln);
                        b.insert(element);
                }
        scnr.close();
}


public static void writeToFile(String filename)
{
    try {
      FileWriter myWriter = new FileWriter(filename);
      myWriter.write("Print student name of student numbers that don't exist:");
      myWriter.write("\nFLDCLA001: "+printStudent("FLDCLA001"));
      myWriter.write("\nXYZ123: "+printStudent("XYZ123"));
      myWriter.write("\n123456789: "+printStudent("123456789"));
      myWriter.write("\nPrint student name of student numbers that do exist:");
      myWriter.write("\nMLLNOA014: "+printStudent("MLLNOA014"));
      myWriter.write("\nWTBJAY001: "+printStudent("WTBJAY001"));
      myWriter.write("\nKHZOMA010: "+printStudent("KHZOMA010"));
      myWriter.write("\nPrint all students:");
      printAllStudents();
       
      myWriter.close();
      System.out.println("Successfully wrote to the file.");
    } catch (IOException e) {
      System.out.println("An error occurred.");
      e.printStackTrace();
    }
    
    System.out.println("Instrumentation: "+Student.OPCOUNT+" comparison operations performed for Access Array.");
    
    
}

public static void writeToExperimentFile(String filename, int num)
{
    try {
       
        
         File f1 = new File(filename);
         if(!f1.exists()) {
            f1.createNewFile();
         }

         FileWriter fileWriter = new FileWriter(f1.getName(),true);
         BufferedWriter bw = new BufferedWriter(fileWriter);
         
       
      System.out.println("EXPERIMENT #"+num+": "+(5000-(num*500))+"lines\n");
      bw.write("EXPERIMENT #"+num+": "+(5000-(num*500))+"lines\n");
      bw.write("Print student name of student numbers that don't exist:");
      bw.write("\nFLDCLA001: "+printStudent("FLDCLA001"));
      bw.write("\nXYZ123: "+printStudent("XYZ123"));
      bw.write("\n123456789: "+printStudent("123456789"));
      bw.write("\nPrint student name of student numbers that do exist:");
      bw.write("\nMLLNOA014: "+printStudent("MLLNOA014"));
      bw.write("\nWTBJAY001: "+printStudent("WTBJAY001"));
      bw.write("\nKHZOMA010: "+printStudent("KHZOMA010"));
      bw.write("\nPrint all students:");
      printAllStudents();
      bw.write("Instrumentation: "+Student.OPCOUNT+" comparison operations performed for Access Array."); 
      System.out.println(Student.OPCOUNT);
      
      
      System.out.println("Successfully wrote to the file.");
      
    	bw.close();
    
      
    } catch (IOException e) {
      System.out.println("An error occurred.");
      e.printStackTrace();
    }
     
}


public static void main(String[] args) throws FileNotFoundException
    {
            Scanner user_input = new Scanner( System.in );
            String fromFile = "";
            String toFile = "";
            char ans;
            int val;
            System.out.println("Are you using oklist.txt? (Y/N)");
            ans = user_input.next().charAt(0);
            if(ans == 'Y' || ans == 'y')
            {
                fromFile = "oklist.txt";
                toFile = "accessarrayapp.txt";
                readInFile(fromFile);
                writeToFile(toFile);
            }
            else
            {
                for(int j = 0; j<10; j++)
                {
                    val = j+1;
		     String fname = "dataset"+val+".txt";
                    fromFile = fname;
                    toFile = "bst_Experiment.txt";
                    readInExperimentFile(fromFile,val);
                    writeToExperimentFile(toFile,val);
                }
                
               
            }
            
    }
}

      
