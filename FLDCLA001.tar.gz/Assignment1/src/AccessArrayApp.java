import java.io.BufferedWriter;
import java.util.Scanner;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.FileNotFoundException;
import java.util.Scanner;



class AccessArrayApp
{       

static int lineNum = 5000;
static Student s[] = new Student[lineNum];

public static void readInFile(String filename) throws FileNotFoundException 
{
	
    File f = new File("/home/fieldy/Assignment1/data/"+filename);
    Scanner scnr = new Scanner(f);

                int counter = 0;
		
                while(scnr.hasNextLine())
                {
                    String sn = "";
                    String fn = "";
                    String ln = "";
                    
                    String line2 = scnr.nextLine();

                        for(int j = 0; j<9;j++)
                        {
                            sn = sn+line2.charAt(j);
                        }
                        int count = 10;
                        
                            while(line2.charAt(count)!=' ')
                            {
                                fn = fn+line2.charAt(count);
                                count++;
                            }
                        
                        
                        for (int l = count+1; l<line2.length(); l++)
                        {
                                ln = ln+line2.charAt(l);
                        }

                        Student element = new Student(sn, fn, ln);
                        s[counter] = element;
                        counter++;
                }

                scnr.close();
}

public static void readInExperimentFile(String filename, int num) throws FileNotFoundException 
{
	if (num ==10)
	{
		lineNum = 5000-(500*num);
	}
	else
	{
		lineNum = 5000-(500*num)-1;
	}
	s = new Student[lineNum];
	
	
    File f = new File("/home/fieldy/Assignment1/data/"+filename);
    Scanner scnr = new Scanner(f);

                int counter = 0;
		
                while(scnr.hasNextLine())
                {
                    String sn = "";
                    String fn = "";
                    String ln = "";
                    
                    String line2 = scnr.nextLine();

                        for(int j = 0; j<9;j++)
                        {
                            sn = sn+line2.charAt(j);
                        }
                        int count = 10;
                        
                            while(line2.charAt(count)!=' ')
                            {
                                fn = fn+line2.charAt(count);
                                count++;
                            }
                        
                        
                        for (int l = count+1; l<line2.length(); l++)
                        {
                                ln = ln+line2.charAt(l);
                        }

                        Student element = new Student(sn, fn, ln);
                        s[counter] = element;
                        counter++;
                }
        scnr.close();
}


public static void writeToFile(String filename)
{
    try {
      FileWriter myWriter = new FileWriter(filename);
      myWriter.write("Print student name of student numbers that don't exist:");
      myWriter.write("\nFLDCLA001: "+printStudent("FLDCLA001"));
      myWriter.write("\nXYZ123: "+printStudent("XYZ123"));
      myWriter.write("\n123456789: "+printStudent("123456789"));
      myWriter.write("\nPrint student name of student numbers that do exist:");
      myWriter.write("\nMLLNOA014: "+printStudent("MLLNOA014"));
      myWriter.write("\nWTBJAY001: "+printStudent("WTBJAY001"));
      myWriter.write("\nKHZOMA010: "+printStudent("KHZOMA010"));
      myWriter.write("\nPrint all students:");
      String all = printAllStudents();
      myWriter.write(all);
       
      
      System.out.println("Successfully wrote to the file.");
      myWriter.close();
    } catch (IOException e) {
      System.out.println("An error occurred.");
      e.printStackTrace();
    }
    
    System.out.println("Instrumentation: "+Student.OPCOUNT+" comparison operations performed for Access Array.");
    
    
}

public static void writeToExperimentFile(String filename, int num)
{
    try {
       
        
         File f1 = new File(filename);
         if(!f1.exists()) {
            f1.createNewFile();
         }

         FileWriter fileWriter = new FileWriter(f1.getName(),true);
         BufferedWriter bw = new BufferedWriter(fileWriter);
         
       
      System.out.println("EXPERIMENT #"+num+": "+(5000-(num*500))+"lines\n");
      bw.write("EXPERIMENT #"+num+": "+(5000-(num*500))+"lines\n");
      bw.write("Print student name of student numbers that don't exist:");
      bw.write("\nFLDCLA001: "+printStudent("FLDCLA001"));
      bw.write("\nXYZ123: "+printStudent("XYZ123"));
      bw.write("\n123456789: "+printStudent("123456789"));
      bw.write("\nPrint student name of student numbers that do exist:");
      bw.write("\nMLLNOA014: "+printStudent("MLLNOA014"));
      bw.write("\nWTBJAY001: "+printStudent("WTBJAY001"));
      bw.write("\nKHZOMA010: "+printStudent("KHZOMA010"));
      bw.write("\nPrint all students:");
      String all = printAllStudents();
      bw.write(all);
      bw.write("Instrumentation: "+Student.OPCOUNT+" comparison operations performed for Access Array."); 
      
       System.out.println("Instrumentation: "+Student.OPCOUNT+" comparison operations performed for Access Array.");
    
      
      System.out.println("Successfully wrote to the file.");
      
       
    	bw.close();
    
      
    } catch (IOException e) {
      System.out.println("An error occurred.");
      e.printStackTrace();
    }
     
}

public static String printAllStudents()
    {
   
    String k = "";
                
         for (int j = 0; j<s.length; j++)
                {
                    k = k+"\n"+s[j].toString();
                }
     return k;
    }
    
    
    public static String printStudent(String stID) 
    {
    
        String name = "";
        boolean found = false;
        
        Student o = new Student(stID, "", "");
        
        for (int i = 0; i<s.length; i++)
        {
        
            if(s[i].compareTo(o) == 0)
            {
                found = true;
                name = s[i].getName()+" "+s[i].getSurname();
            }
        }
        
        if (found == true)
        {
        
            return name;
        }
        else
        {
        
            return "Access denied!";
        }
    }
    
    
    public static void main(String[] args) throws FileNotFoundException
    {
            Scanner user_input = new Scanner( System.in );
            String fromFile = "";
            String toFile = "";
            char ans;
            int val;
            System.out.println("Are you using oklist.txt? (Y/N)");
            ans = user_input.next().charAt(0);
            if(ans == 'Y' || ans == 'y')
            {
                fromFile = "oklist.txt";
                toFile = "accessarrayapp.txt";
                readInFile(fromFile);
                writeToFile(toFile);
            }
            else
            {
                for(int j = 0; j<10; j++)
                {
                    val = j+1;
		     String fname = "dataset"+val+".txt";
                    fromFile = fname;
                    toFile = "array_Experiment.txt";
                    readInExperimentFile(fromFile,val);
                    writeToExperimentFile(toFile,val);
                }
                
               
            }
            
    }
}
