
public class BinaryTreeNode<Student> 
{
   Student data;
   BinaryTreeNode<Student> left;
   BinaryTreeNode<Student> right;
   
   public BinaryTreeNode ( Student d, BinaryTreeNode<Student> l, BinaryTreeNode<Student> r )
   {
      data = d;
      left = l;
      right = r;
   }
   
   BinaryTreeNode<Student> getLeft () { return left; }
   BinaryTreeNode<Student> getRight () { return right; }
   public Student getStudent () { return data; }
}
