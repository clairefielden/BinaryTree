import java.io.BufferedWriter;
import java.util.Scanner;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class BinaryTree<Student> 
{
   BinaryTreeNode<Student> root;
   
   public BinaryTree ()
   {
      root = null;
   }
   

   public void visit ( BinaryTreeNode<Student> node)
   {
   try
   	{
   	File f1 = new File("BSTOutput");
         if(!f1.exists()) {
            f1.createNewFile();
         }

         FileWriter fileWriter = new FileWriter(f1.getName(),true);
         BufferedWriter bw = new BufferedWriter(fileWriter);
   	
   	Student n = node.data;
   	
    	bw.write(n.toString());
    	bw.close();
	}
	catch (IOException e)
	{
		System.out.println("An error occurred.");
      		e.printStackTrace();
	}		
   	
   }
   
   
   public void inOrder ()
   {
     inOrder (root);
   }
   public void inOrder ( BinaryTreeNode<Student> node)
   {
      if (node != null)
      {
         inOrder (node.getLeft());
         visit (node);
         inOrder (node.getRight());
      }   
   }

}
